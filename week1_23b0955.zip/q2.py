import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def PCA(init_array: pd.DataFrame):

    sorted_eigenvalues = None
    final_data = None
    dimensions = 2

    # TODO: transform init_array to final_data using PCA
    init_array = np.array(init_array)
    mean = np.mean(init_array,axis=0)
    init_array -= mean # Step 1: Standardisation without dividing by sigma..

    cov_matrix = np.matmul(init_array.T, init_array)/init_array.shape[0] # Covariance matrix
 
    eigenval,eigenvec = (np.linalg.eig(cov_matrix))
    sort_index = np.argsort(-eigenval) #To sort in descending order
    sorted_eigenvalues = eigenval[sort_index]
    sorted_eigenvalues = np.round(sorted_eigenvalues, decimals=4)
    sorted_eigenvectors = eigenvec[:, sort_index]
    final_data = np.matmul(init_array, sorted_eigenvectors[:dimensions].T)

    # END TODO

    return sorted_eigenvalues, final_data


if __name__ == '__main__':
    init_array = pd.read_csv("pca_data.csv", header = None)
    sorted_eigenvalues, final_data = PCA(init_array)
    np.savetxt("transform.csv", final_data, delimiter = ',')
    for eig in sorted_eigenvalues:
        print(eig)

    # TODO: plot and save a scatter plot of final_data to out.png
    plt.scatter(final_data[:,0], final_data[:,1])
    plt.xlim(-15,15)
    plt.ylim(-15,15)
    ax = plt.gca()
    ax.set_aspect('equal',adjustable='box')
    plt.savefig('out.png')
    plt.close()
    # END TODO
