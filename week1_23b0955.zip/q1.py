import json
import numpy as np
import matplotlib.pyplot as plt

def inv_transform(distribution: str, num_samples: int, **kwargs) -> list:
    """ populate the 'samples' list from the desired distribution """

    samples = []

    # TODO: first generate random numbers from the uniform distribution
    uniform_sample = np.random.uniform(size=num_samples)

    if distribution == 'cauchy':
        '''
            Its quantile function Q := gamma * tan (pi * (u-0.5)) + peak_x
        '''
        gamma = kwargs['gamma']
        peak_x = kwargs['peak_x']
        samples = gamma * np.tan(np.pi * (uniform_sample - 0.5 )) + peak_x

    elif distribution == 'exponential':
        '''
            Its quantie function is Q := -1/lambda * ln (1-u)
        '''
        lambda_ = kwargs['lambda']
        samples = -(np.log(1-uniform_sample))/lambda_
    else:
        return None
    samples = list(np.round(samples, decimals=4))
    # END TODO
            
    return samples


if __name__ == "__main__":
    np.random.seed(42)

    for distribution in ["cauchy", "exponential"]:
        file_name = "q1_" + distribution + ".json"
        args = json.load(open(file_name, "r"))
        samples = inv_transform(**args)
        
        with open("q1_output_" + distribution + ".json", "w") as file:
            json.dump(samples, file)

        # TODO: plot and save the histogram to "q1_" + distribution + ".png"
        plt.hist(samples, bins=100)
        plt.savefig(f'q1_{distribution}.png')
        plt.close()
        # END TODO
